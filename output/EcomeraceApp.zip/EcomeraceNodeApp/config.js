var config = {
  DB_CONNECTION: "mongodb://localhost:27017/EcomeraceDbDB",
  TOKKEN_SECRET: "231sad_ItCanBeAnyRandString_UGHASD82371923192J"
};
module.exports = config;